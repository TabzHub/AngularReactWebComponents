import { CUSTOM_ELEMENTS_SCHEMA, DoBootstrap, Injector, NgModule } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { WebCompOneComponent } from './components/Webcomponent1';
import { WebCompTwoComponent } from './components/Webcomponent2';

@NgModule({
  declarations: [
    AppComponent,
    WebCompOneComponent,
    WebCompTwoComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  entryComponents: [
    AppComponent,
    WebCompOneComponent,
    WebCompTwoComponent
  ],
  schemas:[CUSTOM_ELEMENTS_SCHEMA]
})

export class AppModule implements DoBootstrap {
  constructor(private injector: Injector) {
    const webComponent = createCustomElement(AppComponent, { injector: this.injector });
    customElements.define('angular-component', webComponent);

    const webComponent1 = createCustomElement(WebCompOneComponent, { injector: this.injector });
    customElements.define('web-component-one', webComponent1);

    const webComponent2 = createCustomElement(WebCompTwoComponent, { injector: this.injector });
    customElements.define('web-component-two', webComponent2);
  }

  ngDoBootstrap() { }
}