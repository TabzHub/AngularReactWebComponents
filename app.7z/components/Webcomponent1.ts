
import { Component } from '@angular/core';

@Component({
  selector: 'web-component-1',
  template:`<h3>Web Component 1</h3>`
})
export class WebCompOneComponent {
}
