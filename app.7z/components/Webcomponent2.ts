
import { Component } from '@angular/core';

@Component({
  selector: 'web-component-2',
  template:`<h3>Web Component 2</h3>`
})
export class WebCompTwoComponent {
}
